
  # Site E-commerce Mouslim

  This is a code bundle for Site E-commerce Mouslim. The original project is available at https://www.figma.com/design/YlJOR6BQioRM6hMWJv5s3x/Site-E-commerce-Mouslim.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  